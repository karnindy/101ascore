<?php
function report($id,$from_page){
$sql="select all_.*
from
(select aaa1.iid, aaa1.vvalue, aaa2.return1, aaa2.return2
from
(select aa1.iid, aa1.vvalue, sum(aa1.score) score
from
(
select a.iid, a.vvalue
,case when sum((a.ddesc/b.ddesc) * 100) between 0 and 45 then 104
      when sum((a.ddesc/b.ddesc) * 100) between 45 and 75 then 103
else 94 end score
from
(select iid, substr(vvalue,1,1) vvalue, sum(to_number(ddesc)) ddesc
from z_iinput
where vvalue = '12_1'
group by iid, substr(vvalue,1,1)) a
inner join
(select iid, substr(vvalue,1,1), sum(case when to_number(nvl(ddesc,0)) = 0 then 1 else to_number(nvl(ddesc,0)) end) ddesc
from z_iinput
where vvalue = '12_2'
group by iid, substr(vvalue,1,1)) b on a.iid = b.iid
group by a.iid, a.vvalue

union all

select a.iid, a.vvalue
,case when sum((a.ddesc/b.ddesc) * 100) between 0 and 80 then 115
      when sum((a.ddesc/b.ddesc) * 100) between 80 and 90 then 109
      when sum((a.ddesc/b.ddesc) * 100) between 90 and 100 then 109
 else 109 end score
from
(select iid, substr(vvalue,1,1) vvalue, sum(to_number(ddesc)) ddesc
from z_iinput
where vvalue = '13_1'
group by iid, substr(vvalue,1,1)) a
inner join

(select iid, substr(vvalue,1,1) vvalue, sum(case when to_number(nvl(ddesc,0)) = 0 then 1 else to_number(nvl(ddesc,0)) end) ddesc
from z_iinput
where vvalue = '13_2'
group by iid, substr(vvalue,1,1)) b on a.iid = b.iid
group by a.iid, a.vvalue

union all

select a1.iid, substr(a1.vvalue,1,1) vvalue, sum(to_number(b1.score)) score
from
(select *
from z_iinput
where vvalue not in ('12_1','12_2','13_1','13_2')
and substr(vvalue,1,1) = 1) a1
inner join z_master_map1 b1
on a1.vvalue = b1.loan_code||factor_code||factor_v_code
group by a1.iid, substr(a1.vvalue,1,1)

) aa1
group by aa1.iid, aa1.vvalue) aaa1
inner join z_master_map2 aaa2
on aaa1.vvalue = aaa2.ccode1
and aaa1.score between aaa2.mmin and aaa2.mmax

union all

/* ploan */

select aa2.iid, aa2.vvalue, bb2.return1, bb2.return2
from
(select aa1.iid, aa1.vvalue, sum(aa1.score) score
from
(select iid, substr(vvalue,1,1) vvalue, 93 score
from z_iinput
where vvalue = '26_1'
union all
select a.iid, substr(a.vvalue,1,1) vvalue, b.score
from z_iinput a inner join z_master_map1 b
on a.vvalue = b.loan_code||factor_code||factor_v_code
where substr(vvalue,1,1) = 2
and vvalue <> '26_1') aa1
group by aa1.iid, aa1.vvalue) aa2 inner join z_master_map2 bb2
on aa2.vvalue = bb2.ccode1
and aa2.score between bb2.mmin and bb2.mmax) all_
where all_.iid = '#iid#'
and all_.vvalue = '#vvalue#'
";

if ($from_page=='house') {$from_page=1;
}

if ($from_page=='person') {$from_page=2;
}
$sql=str_replace("#iid#",$id,$sql);
$sql=str_replace("#vvalue#",$from_page,$sql);

return $sql;
}
?>