select bureau_score 
,pl_A 
,npl_A 
,total_A 
,pl_B 
,npl_B 
,total_B 
,pl_C 
,npl_C 
,total_C 
,pl_D 
,npl_D 
,total_D 
,total_pl 
,total_npl 
,total_all
 from (
select b0.sseq 
,b0.bureau_score 
,trim(to_char(b0.pl_A,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.pl_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.pl_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.pl_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.pl_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end pl_A 
,trim(to_char(b0.npl_A,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.npl_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.npl_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.npl_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.npl_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end npl_A 
,trim(to_char(b0.total_A,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.total_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.total_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.total_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.total_A/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end total_A 
,trim(to_char(b0.pl_B,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.pl_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.pl_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.pl_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.pl_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end pl_B 
,trim(to_char(b0.npl_B,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.npl_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.npl_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.npl_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.npl_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end npl_B 
,trim(to_char(b0.total_B,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.total_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.total_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.total_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.total_B/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end total_B 
,trim(to_char(b0.pl_C,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.pl_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.pl_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.pl_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.pl_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end pl_C 
,trim(to_char(b0.npl_C,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.npl_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.npl_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.npl_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.npl_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end npl_C 
,trim(to_char(b0.total_C,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.total_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.total_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.total_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.total_C/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end total_C 
,trim(to_char(b0.pl_D,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.pl_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.pl_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.pl_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.pl_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end pl_D 
,trim(to_char(b0.npl_D,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.npl_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.npl_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.npl_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.npl_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end npl_D 
,trim(to_char(b0.total_D,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.total_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.total_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.total_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.total_D/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end total_D 
,trim(to_char(b0.total_pl,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.total_pl/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.total_pl/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.total_pl/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.total_pl/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end total_pl 
,trim(to_char(b0.total_npl,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.total_npl/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round((b0.total_npl/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round((b0.total_npl/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round((b0.total_npl/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99'))||'%)' end total_npl 
,trim(to_char(b0.total_all,'999,999,999,999,999')) ||' (' ||
case when substr(round((b0.total_all/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0' ||trim(to_char(round((b0.total_all/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99')) ||'%)' when round((b0.total_all/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00' ||'%)' else trim(to_char(round((b0.total_all/
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')) ||'%)' end total_all
 from (
select a0.sseq 
,a0.bureau_score 
,nvl(a1.pl,0) pl_A 
,nvl(a1.npl,0) npl_A 
,nvl(a1.total,0) total_A 
,nvl(a2.pl,0) pl_B 
,nvl(a2.npl,0) npl_B 
,nvl(a2.total,0) total_B 
,nvl(a3.pl,0) pl_C 
,nvl(a3.npl,0) npl_C 
,nvl(a3.total,0) total_C 
,nvl(a4.pl,0) pl_D 
,nvl(a4.npl,0) npl_D 
,nvl(a4.total,0) total_D 
,nvl(a1.pl,0) + nvl(a2.pl,0) + nvl(a3.pl,0) + nvl(a4.pl,0) total_pl 
,nvl(a1.npl,0) + nvl(a2.npl,0) + nvl(a3.npl,0) + nvl(a4.npl,0) total_npl 
,nvl(a1.total,0) + nvl(a2.total,0) + nvl(a3.total,0) + nvl(a4.total,0) total_all
 from master_bure_score a0 left join (
select score_grade 
,sum(pl) pl 
,sum(delmore_90) npl 
,sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
 and grade_desc = 'ระดับความเสี่ยงต่ำ' 
 group by score_grade ) a1 on a0.flag = a1.score_grade left join (
select score_grade 
,sum(pl) pl 
,sum(delmore_90) npl 
,sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
 and grade_desc = 'ระดับความเสี่ยงปานกลาง' 
 group by score_grade ) a2 on a0.flag = a2.score_grade left join (
select score_grade 
,sum(pl) pl 
,sum(delmore_90) npl 
,sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
 and grade_desc = 'ระดับความเสี่ยงค่อนข้างสูง' 
 group by score_grade ) a3 on a0.flag = a3.score_grade left join (
select score_grade 
,sum(pl) pl 
,sum(delmore_90) npl 
,sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
 and grade_desc = 'ระดับความเสี่ยงสูง' 
 group by score_grade ) a4 on a0.flag = a4.score_grade) b0 inner join (
select sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy'))) b1 on 1 = 1 union all 
select 20 sseq 
,'Total' bureau_score 
,trim(to_char(sum(b0.pl_A),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.pl_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.pl_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.pl_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.pl_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_pl_A 
,trim(to_char(sum(b0.npl_A),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.npl_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.npl_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.npl_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.npl_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_npl_A 
,trim(to_char(sum(b0.total_A),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.total_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.total_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.total_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.total_A)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_total_A 
,trim(to_char(sum(b0.pl_B),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.pl_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.pl_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.pl_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.pl_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_pl_B 
,trim(to_char(sum(b0.npl_B),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.npl_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.npl_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.npl_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.npl_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_npl_B 
,trim(to_char(sum(b0.total_B),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.total_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.total_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.total_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.total_B)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_total_B 
,trim(to_char(sum(b0.pl_C),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.pl_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.pl_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.pl_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.pl_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_pl_C 
,trim(to_char(sum(b0.npl_C),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.npl_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.npl_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.npl_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.npl_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_npl_C 
,trim(to_char(sum(b0.total_C),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.total_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.total_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.total_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.total_C)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_total_C 
,trim(to_char(sum(b0.pl_D),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.pl_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.pl_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.pl_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.pl_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_pl_D 
,trim(to_char(sum(b0.npl_D),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.npl_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.npl_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.npl_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.npl_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_npl_D 
,trim(to_char(sum(b0.total_D),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.total_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.total_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.total_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.total_D)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_total_D 
,trim(to_char(sum(b0.total_pl),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.total_pl)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.total_pl)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.total_pl)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.total_pl)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_total_pl 
,trim(to_char(sum(b0.total_npl),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.total_npl)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.total_npl)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.total_npl)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.total_npl)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'999.99')||'%)') end per_total_npl 
,trim(to_char(sum(b0.total_all),'999,999,999,999,999')) ||' (' ||
case when substr(round(sum(b0.total_all)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),1,1) = '.' then '0'||trim(to_char(round(sum(b0.total_all)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2),'.99'))||'%)' when round(sum(b0.total_all)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,2) = 0 then '0.00'||'%)' else trim(to_char(round(sum(b0.total_all)/sum(
case when b0.total_all = 0 then 1 else b0.total_all end)*100,0),'999.99')||'%)') end per_total_all
 from (
select a0.sseq 
,a0.bureau_score 
,nvl(a1.pl,0) pl_A 
,nvl(a1.npl,0) npl_A 
,nvl(a1.total,0) total_A 
,nvl(a2.pl,0) pl_B 
,nvl(a2.npl,0) npl_B 
,nvl(a2.total,0) total_B 
,nvl(a3.pl,0) pl_C 
,nvl(a3.npl,0) npl_C 
,nvl(a3.total,0) total_C 
,nvl(a4.pl,0) pl_D 
,nvl(a4.npl,0) npl_D 
,nvl(a4.total,0) total_D 
,nvl(a1.pl,0) + nvl(a2.pl,0) + nvl(a3.pl,0) + nvl(a4.pl,0) total_pl 
,nvl(a1.npl,0) + nvl(a2.npl,0) + nvl(a3.npl,0) + nvl(a4.npl,0) total_npl 
,nvl(a1.total,0) + nvl(a2.total,0) + nvl(a3.total,0) + nvl(a4.total,0) total_all
 from (
select *
 from master_bure_score 
 where flag = 'Other') a0 left join (
select 'Other' score_grade 
,sum(pl) pl 
,sum(delmore_90) npl 
,sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
 and grade_desc = 'ระดับความเสี่ยงต่ำ' 
 group by 'Other' ) a1 on a0.flag = a1.score_grade left join (
select 'Other' score_grade 
,sum(pl) pl 
,sum(delmore_90) npl 
,sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
 and grade_desc = 'ระดับความเสี่ยงปานกลาง' 
 group by 'Other' ) a2 on a0.flag = a2.score_grade left join (
select 'Other' score_grade 
,sum(pl) pl 
,sum(delmore_90) npl 
,sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
 and grade_desc = 'ระดับความเสี่ยงค่อนข้างสูง' 
 group by 'Other' ) a3 on a0.flag = a3.score_grade left join (
select 'Other' score_grade 
,sum(pl) pl 
,sum(delmore_90) npl 
,sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
 and grade_desc = 'ระดับความเสี่ยงสูง' 
 group by 'Other' ) a4 on a0.flag = a4.score_grade) b0 inner join (
select sum(pl) + sum(delmore_90) total
 from prepare_source_st15 
 where product_type = 'RL-บัตรกดเงินสด GSB' 
 and model_name = 'PRIMA CARD' 
 and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
 or card_type = 'รวมทุกประเภทบัตร') 
 and model_version = '1.0' 
 and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
 or sales_channel in ('รวมทุกช่องทาง')) 
 and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
 or business_type in ('รวมทุกสายงานกิจการ')) 
 and ('รวมทุกภาค' = 'รวมทุกภาค' 
 or region_name in ('รวมทุกภาค')) 
 and ('รวมทุกเขต' = 'รวมทุกเขต' 
 or zone_name in ('รวมทุกเขต')) 
 and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
 or branch_name in ('รวมทุกสาขา')) 
 and create_date between to_date('01/11/2020','dd/mm/yyyy') 
 and last_day(to_date('30/11/2021','dd/mm/yyyy'))) b1 on 1 = 1 
 group by 'Total') all_full 
 order by all_full.sseq asc