select aa.category 
,aa.total_actual_3m 
,round(aa.total_actual_3m/
case when bb.total_actual_3m = 0 then 1 else bb.total_actual_3m end *100,2) oper_override_3m 
,aa.total_actual_6m 
,round(aa.total_actual_6m/
case when bb.total_actual_6m = 0 then 1 else bb.total_actual_6m end *100,2) per_override_6m 
,aa.total_actual_12m 
,round(aa.total_actual_12m/
case when bb.total_actual_12m = 0 then 1 else bb.total_actual_12m end *100,2) per_override_12m 
from (
select a.reason_code_desc_2 category 
,nvl(b.total_actual,0) total_actual_3m 
,nvl(c.total_actual,0) total_actual_6m 
,nvl(d.total_actual,0) total_actual_12m 
from master_reason_desc a left join (
select reason_code_desc 
,sum(nvl(pass_cutoff_reject,0)) pass_cutoff_reject 
,sum(nvl(below_cutoff_approve,0)) below_cutoff_approve 
,sum(nvl(approve_rpt1,0)+nvl(reject_rpt1,0)) total_actual 
from prepare_source_st7 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between add_months(last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')),-3)+1 
and last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')) 
group by reason_code_desc) b on substr(a.reason_code_desc_2,1,4) = b.reason_code_desc left join (
select reason_code_desc 
,sum(nvl(pass_cutoff_reject,0)) pass_cutoff_reject 
,sum(nvl(below_cutoff_approve,0)) below_cutoff_approve 
,sum(nvl(approve_rpt1,0)+nvl(reject_rpt1,0)) total_actual 
from prepare_source_st7 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between add_months(last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')),-6)+1 
and last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')) 
group by reason_code_desc) c on substr(a.reason_code_desc_2,1,4) = c.reason_code_desc left join (
select reason_code_desc 
,sum(nvl(pass_cutoff_reject,0)) pass_cutoff_reject 
,sum(nvl(below_cutoff_approve,0)) below_cutoff_approve 
,sum(nvl(approve_rpt1,0)+nvl(reject_rpt1,0)) total_actual 
from prepare_source_st7 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between add_months(last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')),-12)+1 
and last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')) 
group by reason_code_desc) d on substr(a.reason_code_desc_2,1,4) = d.reason_code_desc) aa inner join (
select sum(nvl(b.total_actual,0)) total_actual_3m 
,sum(nvl(c.total_actual,0)) total_actual_6m 
,sum(nvl(d.total_actual,0)) total_actual_12m 
from master_reason_desc a left join (
select reason_code_desc 
,sum(nvl(pass_cutoff_reject,0)) pass_cutoff_reject 
,sum(nvl(below_cutoff_approve,0)) below_cutoff_approve 
,sum(nvl(approve_rpt1,0)+nvl(reject_rpt1,0)) total_actual 
from prepare_source_st7 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between add_months(last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')),-3)+1 
and last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')) 
group by reason_code_desc) b on substr(a.reason_code_desc_2,1,4) = b.reason_code_desc left join (
select reason_code_desc 
,sum(nvl(pass_cutoff_reject,0)) pass_cutoff_reject 
,sum(nvl(below_cutoff_approve,0)) below_cutoff_approve 
,sum(nvl(approve_rpt1,0)+nvl(reject_rpt1,0)) total_actual 
from prepare_source_st7 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between add_months(last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')),-6)+1 
and last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')) 
group by reason_code_desc) c on substr(a.reason_code_desc_2,1,4) = c.reason_code_desc left join (
select reason_code_desc 
,sum(nvl(pass_cutoff_reject,0)) pass_cutoff_reject 
,sum(nvl(below_cutoff_approve,0)) below_cutoff_approve 
,sum(nvl(approve_rpt1,0)+nvl(reject_rpt1,0)) total_actual 
from prepare_source_st7 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') --and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between add_months(last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')),-12)+1 
and last_day(to_date('01'||'/'||'11'||'/'||'2020','dd/mm/yyyy')) 
group by reason_code_desc) d on substr(a.reason_code_desc_2,1,4) = d.reason_code_desc) bb on 1 = 1 
order by aa.category asc