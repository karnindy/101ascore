select total_all_order.scoregrade
,total_all_order.active_account
,total_all_order.active_amount
,total_all_order.npls_account
,total_all_order.per_npls
,total_all_order.ncb_amount
,total_all_order.per_ncb_amount
,total_all_order.per_cum_npl per_cum_npl
from
(select max(total_all.score_range_id) score_range_id
,total_all.scoregrade
,total_all.active_account
,total_all.active_amount
,total_all.npls_account
,total_all.per_npls
,total_all.ncb_amount
,total_all.per_ncb_amount
,total_all.per_cum_npl

from
(select aaa.score_range_id
,aaa.scoregrade
,aaa.active_account
,aaa.active_amount
,aaa.npls_account
,aaa.per_npls
,aaa.ncb_amount
,aaa.per_ncb_amount

,to_char(nvl(bbb.per_cum_npl,'0')) per_cum_npl
from

(select aa.score_range_id
,aa.scoregrade
,nvl(active_account,0) active_account
,nvl(active_amount,0) active_amount
,nvl(npls_account,0) npls_account
,nvl(per_npls,0) per_npls
,nvl(ncb_amount,0) ncb_amount
,nvl(per_ncb_amount,0) per_ncb_amount
from (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) aa
left join
(select a.scoregrade
,sum(a.active) active_account
,sum(a.current_balance) active_amount
,sum(a.delmore_90) npls_account
,round((sum(a.delmore_90)/case when sum(a.active) = 0 then 1 else sum(a.active) end) * 100,2) per_npls
,sum(a.ncb_amount) ncb_amount
,round((sum(a.ncb_amount)/case when sum(a.current_balance) = 0 then 1 else sum(a.current_balance) end) * 100,2) per_ncb_amount
from prepare_source_st13 a
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
group by a.scoregrade) bb on aa.scoregrade = bb.scoregrade 
where aa.flag = 'PEOPLE CARD') aaa

left join

(select pre.score_range_id score_range_id
,sum(post.npls_account) npls_account
,sum(post.active_account) active_account
,round((sum(post.npls_account)/case when nvl(sum(post.active_account),0) = 0 then 1 else nvl(sum(post.active_account),0) end)*100,2)per_cum_npl
from
(select aa.score_range_id
,nvl(npls_account,0) npls_account
,nvl(active_account,0) active_account
from (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) aa
left join
(select a.scoregrade
,sum(a.active) active_account
,sum(a.current_balance) current_balance
,sum(a.delmore_90) npls_account
,round((sum(a.delmore_90)/case when max(nvl(b.total_active,0)) = 0 then 1 else max(nvl(b.total_active,0)) end) * 100,2) per_npls
,sum(a.ncb_amount) ncb_amount
,round((sum(a.ncb_amount)/case when max(nvl(b.total_active,0)) = 0 then 1 else max(nvl(b.total_active,0)) end) * 100,2) per_ncb_amount
from prepare_source_st13 a inner join (select sum(active) total_active from prepare_source_st13) b on 1 = 1
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
group by a.scoregrade) bb on aa.scoregrade = bb.scoregrade 
where aa.flag = 'PEOPLE CARD'
and aa.score_range_id <= (select max(b.score_range_id) score_range_id
from prepare_source_st13 a inner join (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) b 
on a.scoregrade =  b.scoregrade
and a.model_name = b.flag
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
)
) pre
inner join

(select aa.score_range_id
,nvl(npls_account,0) npls_account
,nvl(active_account,0) active_account
from (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) aa
left join
(select a.scoregrade
,sum(a.active) active_account
,sum(a.current_balance) current_balance
,sum(a.delmore_90) npls_account
,round((sum(a.delmore_90)/case when max(nvl(b.total_active,0)) = 0 then 1 else max(nvl(b.total_active,0)) end) * 100,2) per_npls
,sum(a.ncb_amount) ncb_amount
,round((sum(a.ncb_amount)/case when max(nvl(b.total_active,0)) = 0 then 1 else max(nvl(b.total_active,0)) end) * 100,2) per_ncb_amount
from prepare_source_st13 a inner join (select sum(active) total_active from prepare_source_st13) b on 1 = 1
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
group by a.scoregrade) bb on aa.scoregrade = bb.scoregrade 
where aa.flag = 'PEOPLE CARD'
and aa.score_range_id <= (select max(b.score_range_id) score_range_id
from prepare_source_st13 a inner join (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) b 
on a.scoregrade =  b.scoregrade
and a.model_name = b.flag
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy')))
) post on pre.score_range_id >= post.score_range_id
group by pre.score_range_id) bbb on aaa.score_range_id = bbb.score_range_id

union all

select total_1.score_range_id
,total_1.scoregrade
,total_1.active_account
,total_1.active_amount
,total_1.npls_account
,total_1.per_npls
,total_1.ncb_amount
,total_1.per_ncb_amount
,'' per_cum_npl

from

(select 0 score_range_id
,'Total' scoregrade
,sum(a.active) active_account
,sum(a.current_balance) active_amount
,sum(a.delmore_90) npls_account
,round((sum(a.delmore_90)/case when sum(a.active) = 0 then 1 else sum(a.active) end) * 100,2) per_npls
,sum(a.ncb_amount) ncb_amount
,round((sum(a.ncb_amount)/case when sum(a.current_balance) = 0 then 1 else sum(a.current_balance) end) * 100,2) per_ncb_amount
from prepare_source_st13 a
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
group by 0, 'Total') total_1

inner join

(select 0 score_range_id
,'Total' scoregrade

,max(round((sum(post.npls_account)/case when nvl(sum(post.active_account),0) = 0 then 1 else nvl(sum(post.active_account),0) end)*100,2)) per_cum_npl
from
(select aa.score_range_id
,nvl(npls_account,0) npls_account
,nvl(active_account,0) active_account
from (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) aa
left join
(select a.scoregrade
,sum(a.active) active_account
,sum(a.current_balance) current_balance
,sum(a.delmore_90) npls_account
,round((sum(a.delmore_90)/case when max(nvl(b.total_active,0)) = 0 then 1 else max(nvl(b.total_active,0)) end) * 100,2) per_npls
,sum(a.ncb_amount) ncb_amount
,round((sum(a.ncb_amount)/case when max(nvl(b.total_active,0)) = 0 then 1 else max(nvl(b.total_active,0)) end) * 100,2) per_ncb_amount
from prepare_source_st13 a inner join (select sum(active) total_active from prepare_source_st13) b on 1 = 1
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
group by a.scoregrade) bb on aa.scoregrade = bb.scoregrade 
where aa.flag = 'PEOPLE CARD'
and aa.score_range_id <= (select max(b.score_range_id) score_range_id
from prepare_source_st13 a inner join (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) b 
on a.scoregrade =  b.scoregrade
and a.model_name = b.flag
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy')))
) pre

inner join

(select aa.score_range_id
,nvl(npls_account,0) npls_account
,nvl(active_account,0) active_account
from (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) aa
left join
(select a.scoregrade
,sum(a.active) active_account
,sum(a.current_balance) current_balance
,sum(a.delmore_90) npls_account
,round((sum(a.delmore_90)/case when max(nvl(b.total_active,0)) = 0 then 1 else max(nvl(b.total_active,0)) end) * 100,2) per_npls
,sum(a.ncb_amount) ncb_amount
,round((sum(a.ncb_amount)/case when max(nvl(b.total_active,0)) = 0 then 1 else max(nvl(b.total_active,0)) end) * 100,2) per_ncb_amount
from prepare_source_st13 a inner join (select sum(active) total_active from prepare_source_st13) b on 1 = 1
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
group by a.scoregrade) bb on aa.scoregrade = bb.scoregrade 
where aa.flag = 'PEOPLE CARD'
and aa.score_range_id <= (select max(b.score_range_id) score_range_id
from prepare_source_st13 a inner join (select max(score_range_id) score_range_id, flag, scoregrade from score_range_master group by scoregrade, flag) b 
on a.scoregrade =  b.scoregrade
and a.model_name = b.flag
where a.product_type = 'RL-บัตรกดเงินสด GSB'
and a.model_name = 'PEOPLE CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or a.card_type = 'รวมทุกประเภทบัตร')
and a.model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or a.sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or a.business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or a.region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or a.zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or a.branch_name in ('รวมทุกสาขา'))
and a.create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy')))) post on pre.score_range_id >= post.score_range_id
group by 0,'Total') total_2 on total_1.score_range_id = total_2.score_range_id 
and total_1.scoregrade = total_2.scoregrade
) total_all
group by total_all.scoregrade
,total_all.active_account
,total_all.active_amount
,total_all.npls_account
,total_all.per_npls
,total_all.ncb_amount
,total_all.per_ncb_amount
,total_all.per_cum_npl) total_all_order
order by total_all_order.score_range_id desc