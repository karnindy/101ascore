select all_.grade_desc
,all_.approve_rpt2
,all_.per_approve_rpt2
,all_.reject_rpt2
,all_.per_reject_rpt2
,all_.cancel_rpt2
,all_.per_cancel_rpt2
,all_.incompleted
,all_.per_incompleted

,all_.pending
,all_.per_pending

,all_.other
,all_.per_other
,all_.total_status
,all_.per_total_status
,all_.pl
,all_.per_pl
,all_.npl
,all_.per_npl
from
(select aa.score_range_id
,aa.grade_desc
,nvl(approve_rpt2,0) approve_rpt2
,nvl(per_approve_rpt2,0) per_approve_rpt2
,nvl(reject_rpt2,0) reject_rpt2
,nvl(per_reject_rpt2,0) per_reject_rpt2
,nvl(cancel_rpt2,0) cancel_rpt2
,nvl(per_cancel_rpt2,0) per_cancel_rpt2
,nvl(incompleted,0) incompleted
,nvl(per_incompleted,0) per_incompleted

,nvl(pending,0) pending
,nvl(per_pending,0) per_pending

,nvl(other,0) other
,nvl(per_other,0) per_other
,nvl(total_status,0) total_status
,nvl(per_total_status,0) per_total_status
,nvl(pl,0) pl
,nvl(per_pl,0) per_pl
,nvl(npl,0) npl
,nvl(per_npl,0) per_npl
from
(select grade_desc, max(score_range_id) score_range_id
from score_range_master
group by grade_desc) aa

left join

(select a.grade_desc
,sum(a.approve_rpt2) approve_rpt2
,round((sum(a.approve_rpt2)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_approve_rpt2
,sum(a.reject_rpt2) reject_rpt2
,round((sum(a.reject_rpt2)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_reject_rpt2
,sum(a.cancel_rpt2) cancel_rpt2
,round((sum(a.cancel_rpt2)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_cancel_rpt2
,sum(a.incompleted) incompleted
,round((sum(a.incompleted)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_incompleted

,sum(a.pending) pending
,round((sum(a.pending)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_pending

,sum(a.other) other
,round((sum(a.other)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_other
,sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) total_status
,round((sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other)/case when max(b.total_status) = 0 then 1 else max(b.total_status) end) * 100,2) per_total_status
,sum(a.pl) pl
,round((sum(a.pl)/case when sum(a.pl)+sum(a.delmore_90) = 0 then 1 else sum(a.pl)+sum(a.delmore_90) end) * 100,2) per_pl
,sum(a.delmore_90) npl
,round((sum(a.delmore_90)/case when sum(a.pl)+sum(a.delmore_90) = 0 then 1 else sum(a.pl)+sum(a.delmore_90) end) * 100,2) per_npl
from prepare_source_st15 a inner join (select sum(approve_rpt2 + reject_rpt2 + cancel_rpt2 + incompleted + pending + other) total_status
from prepare_source_st15
where product_type = 'CC-บัตรเครดิต'
and model_name = 'CREDIT CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
) b on 1 = 1
where product_type = 'CC-บัตรเครดิต'
and model_name = 'CREDIT CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))                                                            
group by a.grade_desc
) bb on aa.grade_desc = bb.grade_desc

union all

select 0 score_range_id
,'Total' grade_desc
,sum(a.approve_rpt2) approve_rpt2
,round((sum(a.approve_rpt2)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_approve_rpt2
,sum(a.reject_rpt2) reject_rpt2
,round((sum(a.reject_rpt2)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_reject_rpt2
,sum(a.cancel_rpt2) cancel_rpt2
,round((sum(a.cancel_rpt2)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_cancel_rpt2
,sum(a.incompleted) incompleted
,round((sum(a.incompleted)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_incompleted

,sum(a.pending) pending
,round((sum(a.pending)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_pending

,sum(a.other) other
,round((sum(a.other)/case when sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) = 0 then 1 else sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) end) * 100,2) per_other
,sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other) total_status
,round((sum(a.approve_rpt2 + a.reject_rpt2 + a.cancel_rpt2 + a.incompleted + a.pending + a.other)/case when max(b.total_status) = 0 then 1 else max(b.total_status) end) * 100,2) per_total_status
,sum(a.pl) pl
,round((sum(a.pl)/case when sum(a.pl)+sum(a.delmore_90) = 0 then 1 else sum(a.pl)+sum(a.delmore_90) end) * 100,2) per_pl
,sum(a.delmore_90) npl
,round((sum(a.delmore_90)/case when sum(a.pl)+sum(a.delmore_90) = 0 then 1 else sum(a.pl)+sum(a.delmore_90) end) * 100,2) per_npl
from prepare_source_st15  a inner join (select sum(approve_rpt2 + reject_rpt2 + cancel_rpt2 + incompleted + pending + other) total_status
from prepare_source_st15
where product_type = 'CC-บัตรเครดิต'
and model_name = 'CREDIT CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
) b on 1 = 1
where product_type = 'CC-บัตรเครดิต'
and model_name = 'CREDIT CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between to_date('01/11/2020','dd/mm/yyyy')
and last_day(to_date('30/11/2021','dd/mm/yyyy'))
) all_
order by all_.score_range_id desc