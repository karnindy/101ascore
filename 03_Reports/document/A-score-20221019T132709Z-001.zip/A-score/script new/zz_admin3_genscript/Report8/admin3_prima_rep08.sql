select all_total.score_range_desc
,all_total.bad1_30past3months
,all_total.bad1_30past12months
,all_total.bad1_30pastmore12
,all_total.bad31_60past3months
,all_total.bad31_60past12months
,all_total.bad31_60pastmore12
,all_total.bad61_90past3months
,all_total.bad61_90past12months
,all_total.bad61_90pastmore12
from
(select aaa.score_range_id
,aaa.score_range_desc
,round(nvl(approve_3m.ever1_30,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end * 100,2) bad1_30past3months
,round(nvl(approve_12m.ever1_30,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end * 100,2) bad1_30past12months
,round(nvl(approve_more12m.ever1_30,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end * 100,2) bad1_30pastmore12

,round(nvl(approve_3m.ever31_60,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end * 100,2) bad31_60past3months
,round(nvl(approve_12m.ever31_60,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end * 100,2) bad31_60past12months
,round(nvl(approve_more12m.ever31_60,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end * 100,2) bad31_60pastmore12

,round(nvl(approve_3m.ever61_90,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end * 100,2) bad61_90past3months
,round(nvl(approve_12m.ever61_90,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end * 100,2) bad61_90past12months
,round(nvl(approve_more12m.ever61_90,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end * 100,2) bad61_90pastmore12
from score_range_master aaa
left join (select a.score_range_desc
,a.product_type
,'PRIMA CARD' flag
,sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-4))+1
and last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-1))
group by a.score_range_desc
,a.product_type
,'PRIMA CARD'
) approve_3m on aaa.score_range_desc = approve_3m.score_range_desc and aaa.flag = approve_3m.flag

left join (select a.score_range_desc
,a.product_type
,'PRIMA CARD' flag
,sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-13))+1
and last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-1))
group by a.score_range_desc
,a.product_type
,'PRIMA CARD'
) approve_12m on aaa.score_range_desc = approve_12m.score_range_desc and aaa.flag = approve_12m.flag
left join (select a.score_range_desc
,a.product_type
,'PRIMA CARD' flag
,sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date < last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-13))+1
group by a.score_range_desc
,a.product_type
,'PRIMA CARD'
) approve_more12m on aaa.score_range_desc = approve_more12m.score_range_desc and aaa.flag = approve_more12m.flag
where aaa.flag = 'PRIMA CARD'

union all

select 20
,'Total'
,sum(round(nvl(approve_3m.ever1_30,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end * 100,2)) bad1_30past3months
,sum(round(nvl(approve_12m.ever1_30,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end * 100,2)) bad1_30past12months
,sum(round(nvl(approve_more12m.ever1_30,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end * 100,2)) bad1_30pastmore12

,sum(round(nvl(approve_3m.ever31_60,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end * 100,2)) bad31_60past3months
,sum(round(nvl(approve_12m.ever31_60,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end * 100,2)) bad31_60past12months
,sum(round(nvl(approve_more12m.ever31_60,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end * 100,2)) bad31_60pastmore12

,sum(round(nvl(approve_3m.ever61_90,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end * 100,2)) bad61_90past3months
,sum(round(nvl(approve_12m.ever61_90,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end * 100,2)) bad61_90past12months
,sum(round(nvl(approve_more12m.ever61_90,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end * 100,2)) bad61_90pastmore12
from score_range_master aaa
left join (select a.score_range_desc
,a.product_type
,'PRIMA CARD' flag
,sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-4))+1
and last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-1))
group by a.score_range_desc
,a.product_type
,'PRIMA CARD'
) approve_3m on aaa.score_range_desc = approve_3m.score_range_desc and aaa.flag = approve_3m.flag

left join (select a.score_range_desc
,a.product_type
,'PRIMA CARD' flag
,sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-13))+1
and last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-1))
group by a.score_range_desc
,a.product_type
,'PRIMA CARD'
) approve_12m on aaa.score_range_desc = approve_12m.score_range_desc and aaa.flag = approve_12m.flag
left join (select a.score_range_desc
,a.product_type
,'PRIMA CARD' flag
,sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date < last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-13))+1
group by a.score_range_desc
,a.product_type
,'PRIMA CARD'
) approve_more12m on aaa.score_range_desc = approve_more12m.score_range_desc and aaa.flag = approve_more12m.flag
where aaa.flag = 'PRIMA CARD'

union all

select 30
,'Average Bad Rate'
,sum(round(nvl(approve_3m.ever1_30,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end,2)) bad1_30past3months
,sum(round(nvl(approve_12m.ever1_30,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end,2)) bad1_30past12months
,sum(round(nvl(approve_more12m.ever1_30,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end,2)) bad1_30pastmore12

,sum(round(nvl(approve_3m.ever31_60,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end,2)) bad31_60past3months
,sum(round(nvl(approve_12m.ever31_60,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end,2)) bad31_60past12months
,sum(round(nvl(approve_more12m.ever31_60,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end,2)) bad31_60pastmore12

,sum(round(nvl(approve_3m.ever61_90,0)/case when nvl(approve_3m.approve,0) = 0 then 1 else approve_3m.approve end,2)) bad61_90past3months
,sum(round(nvl(approve_12m.ever61_90,0)/case when nvl(approve_12m.approve,0) = 0 then 1 else approve_12m.approve end,2)) bad61_90past12months
,sum(round(nvl(approve_more12m.ever61_90,0)/case when nvl(approve_more12m.approve,0) = 0 then 1 else approve_more12m.approve end,2)) bad61_90pastmore12
from dual aaa
left join (select sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-4))+1
and last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-1))
) approve_3m on 1 = 1

left join (select sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date between last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-13))+1
and last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-1))
) approve_12m on 1 = 1
left join (select sum(a.approve_rpt1) approve
,sum(nvl(b.ever1_30,0)) ever1_30
,sum(nvl(b.ever31_60,0)) ever31_60
,sum(nvl(b.ever61_90,0)) ever61_90
from prepare_source_st10 a left join prepare_source_st9 b on a.appl_id = b.appl_id and substr(a.card_type,1,3) = b.account_type
where product_type = 'RL-บัตรกดเงินสด GSB'
and model_name = 'PRIMA CARD'
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' or card_type = 'รวมทุกประเภทบัตร')
and model_version = '1.0'
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' or sales_channel in ('รวมทุกช่องทาง'))
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' or business_type in ('รวมทุกสายงานกิจการ'))
and ('รวมทุกภาค' = 'รวมทุกภาค' or region_name in ('รวมทุกภาค'))
and ('รวมทุกเขต' = 'รวมทุกเขต' or zone_name in ('รวมทุกเขต'))
and ('รวมทุกสาขา' = 'รวมทุกสาขา' or branch_name in ('รวมทุกสาขา'))
and create_date < last_day(add_months(to_date('01/'||'11'||'2020','dd/mm/yyyy'),-13))+1
) approve_more12m on 1 = 1) all_total
order by all_total.score_range_id asc