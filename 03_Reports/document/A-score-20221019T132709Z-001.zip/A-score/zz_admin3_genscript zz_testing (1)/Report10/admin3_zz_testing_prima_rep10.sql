select aaa.score_range_desc 
,aaa.per_accept_acct 
,aaa.per_active_acct 
,aaa.per_current_1_30 
,aaa.per_current_31_60 
,aaa.per_current_61_90 
,aaa.per_current_more_90 
from (
select aa.score_range_id 
,aa.score_range_desc 
,nvl(bb.per_accept_acct,0) per_accept_acct 
,nvl(bb.per_active_acct,0) per_active_acct 
,nvl(bb.per_current_1_30,0) per_current_1_30 
,nvl(bb.per_current_31_60,0) per_current_31_60 
,nvl(bb.per_current_61_90,0) per_current_61_90 
,nvl(bb.per_current_more_90,0) per_current_more_90 
from score_range_master aa left join (
select a.score_range_desc 
,to_char('('||(sum(a.approve)||'/'||
case when nvl(max(b.total_approve),0) = 0 then 1 else nvl(max(b.total_approve),0) end)||')*100') per_accept_acct 
,to_char('('||(sum(a.active)||'/'||
case when sum(a.approve) = 0 then 1 else sum(a.approve) end)||')*100') per_active_acct 
,to_char('('||(sum(a.ever1_30)||'/'||
case when sum(a.active) = 0 then 1 else sum(a.active) end)||')*100') per_current_1_30 
,to_char('('||(sum(a.ever31_60)||'/'||
case when sum(a.active) = 0 then 1 else sum(a.active) end)||')*100') per_current_31_60 
,to_char('('||(sum(a.ever61_90)||'/'||
case when sum(a.active) = 0 then 1 else sum(a.active) end)||')*100') per_current_61_90 
,to_char('('||(sum(a.delmore_90)||'/'||
case when sum(a.active) = 0 then 1 else sum(a.active) end)||')*100') per_current_more_90 
from prepare_source_st11 a inner join (
select sum(approve) total_approve 
,sum(active) total_active 
from prepare_source_st11 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/'||'11'||'2020','dd/mm/yyyy') 
and last_day(to_date('01/'||'11'||'2021','dd/mm/yyyy'))) b on 1 = 1 
where a.product_type = 'RL-บัตรกดเงินสด GSB' 
and a.model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or a.card_type = 'รวมทุกประเภทบัตร') 
and a.model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or a.sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or a.business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or a.region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or a.zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or a.branch_name in ('รวมทุกสาขา')) 
and a.create_date between to_date('01/'||'11'||'2020','dd/mm/yyyy') 
and last_day(to_date('01/'||'11'||'2021','dd/mm/yyyy')) 
group by a.score_range_desc) bb on aa.score_range_desc = bb.score_range_desc 
where aa.flag = 'PRIMA CARD' union all 
select 20 score_range_id 
,'Total' 
,to_char('('||(sum(a.approve)||'/'||
case when nvl(max(b.total_approve),0) = 0 then 1 else nvl(max(b.total_approve),0) end)||')*100') per_accept_acct 
,to_char('('||(sum(a.active)||'/'||
case when sum(a.approve) = 0 then 1 else sum(a.approve) end)||')*100') per_active_acct 
,to_char('('||(sum(a.ever1_30)||'/'||
case when sum(a.active) = 0 then 1 else sum(a.active) end)||')*100') per_current_1_30 
,to_char('('||(sum(a.ever31_60)||'/'||
case when sum(a.active) = 0 then 1 else sum(a.active) end)||')*100') per_current_31_60 
,to_char('('||(sum(a.ever61_90)||'/'||
case when sum(a.active) = 0 then 1 else sum(a.active) end)||')*100') per_current_61_90 
,to_char('('||(sum(a.delmore_90)||'/'||
case when sum(a.active) = 0 then 1 else sum(a.active) end)||')*100') per_current_more_90 
from prepare_source_st11 a inner join (
select sum(approve) total_approve ,sum(active) total_active 
from prepare_source_st11 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/'||'11'||'2020','dd/mm/yyyy') 
and last_day(to_date('01/'||'11'||'2021','dd/mm/yyyy'))) b on 1 = 1 
where a.product_type = 'RL-บัตรกดเงินสด GSB' 
and a.model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or a.card_type = 'รวมทุกประเภทบัตร') 
and a.model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or a.sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or a.business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or a.region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or a.zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or a.branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/'||'11'||'2020','dd/mm/yyyy') 
and last_day(to_date('01/'||'11'||'2021','dd/mm/yyyy')) 
group by 'Total') aaa 
order by aaa.score_range_id asc