select all_.score_range_desc 
,all_.dev 
,all_.per_dev 
,all_.actual 
,all_.per_actual 
,all_.per_change 
,all_.ratio 
,all_.woe 
,all_.index_ 
,all_.per_approve 
,all_.per_reject 
from (
select aaa.score_range_id 
,aaa.score_range_desc 
,max(nvl(ccc.dev,0)) dev 
,'('||max(nvl(ccc.dev,0)) ||'/'|| 
case when max(nvl(ccc.total_dev,0)) = 0 then 0 else max(nvl(ccc.total_dev,0)) end ||') * 100' per_dev 
,sum(nvl(bbb.actual,0)) actual 
,'('||sum(nvl(bbb.actual,0)) ||'/'|| 
case when sum(nvl(bbb.total_actual,0)) = 0 then 0 else sum(nvl(bbb.total_actual,0)) end||') * 100' per_actual 
,'%Actual - %Dev' per_change 
,'%Actual / %Dev' ratio 
,'Ln(Ratio)' woe 
,'(%Change /100) * Ln(Ratio)' index_ 
,to_char(max(nvl(ddd.per_approve,0))) per_approve 
,to_char(max(nvl(ddd.per_reject,0))) per_reject 
from score_range_master aaa left join (
select a.score_range_desc 
,sum(a.approve_rpt1 + a.reject_rpt1) actual 
,max(b.actual) total_actual 
from prepare_source_st4 a inner join (
select sum(approve_rpt1+reject_rpt1) actual 
from prepare_source_st4 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/11/2020','dd/mm/yyyy') 
and to_date('30/11/2021','dd/mm/yyyy') ) b on 1 = 1 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and a.create_date between to_date('01/11/2020','dd/mm/yyyy') 
and to_date('30/11/2021','dd/mm/yyyy') 
group by a.score_range_desc ) bbb on aaa.score_range_desc = bbb.score_range_desc left join (
select a.score_range_desc 
,sum(a.bad) bad 
,sum(a.good) good 
,sum(a.dev) dev 
,max(b.bad) total_bad 
,max(b.good) total_good 
,max(b.dev) total_dev 
from prepare_source_st3 a inner join (
select sum(bad) bad 
,sum(good) good 
,sum(dev) dev 
from prepare_source_st3 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') ) b on 1 = 1 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and (card_type = 'รวมทุกประเภทบัตร') 
group by a.score_range_desc ) ccc on aaa.score_range_desc = ccc.score_range_desc left join (
select a.score_range_desc 
,to_char('('||a.approve||'/'||b.total_approve||')'||'*'||100) per_approve 
,to_char('('||a.reject||'/'||c.total_reject||')'||'*'||100) per_reject 
from (
select sum(approve_rpt1) approve 
,sum(reject_rpt1) reject 
,score_range_desc 
from prepare_source_st4 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/11/2020','dd/mm/yyyy') 
and to_date('30/11/2021','dd/mm/yyyy') 
group by score_range_desc) a inner join (
select 
case when sum(approve_rpt1) = 0 then 0 else sum(approve_rpt1) end total_approve 
from prepare_source_st4 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/11/2020','dd/mm/yyyy') 
and to_date('30/11/2021','dd/mm/yyyy') ) b on 1 = 1 inner join (
select 
case when sum(reject_rpt1) = 0 then 0 else sum(reject_rpt1) end total_reject 
from prepare_source_st4 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PRIMA CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/11/2020','dd/mm/yyyy') 
and to_date('30/11/2021','dd/mm/yyyy') ) c on 1 = 1) ddd on aaa.score_range_desc = ddd.score_range_desc 
where aaa.flag = 'PRIMA CARD' 
group by aaa.score_range_id, aaa.score_range_desc ) all_ 
order by all_.score_range_id