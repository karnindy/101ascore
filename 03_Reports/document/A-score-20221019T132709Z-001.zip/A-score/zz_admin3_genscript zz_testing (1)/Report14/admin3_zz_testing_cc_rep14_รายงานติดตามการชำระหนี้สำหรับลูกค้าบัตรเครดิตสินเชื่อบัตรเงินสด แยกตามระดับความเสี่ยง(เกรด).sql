select all_.grade_desc 
,all_.ever0 
,all_.per_ever0 
,all_.ever1_30 
,all_.per_ever1_30 
,all_.ever31_60 
,all_.per_ever31_60 
,all_.ever61_90 
,all_.per_ever61_90 
,all_.delmore_90 
,all_.per_ever_more90 
,all_.total_active 
,all_.per_active 
from (
select aa.score_range_id 
,aa.grade_desc grade_desc 
,nvl(bb.ever0,0) ever0 
,nvl(bb.per_ever0,0) per_ever0 
,nvl(bb.ever1_30,0) ever1_30 
,nvl(bb.per_ever1_30,0) per_ever1_30 
,nvl(bb.ever31_60,0) ever31_60 
,nvl(bb.per_ever31_60,0) per_ever31_60 
,nvl(bb.ever61_90,0) ever61_90 
,nvl(bb.per_ever61_90,0) per_ever61_90 
,nvl(bb.delmore_90,0) delmore_90 
,nvl(bb.per_ever_more90,0) per_ever_more90 
,nvl(bb.total_active,0) total_active 
,nvl(bb.per_active,0) per_active 
from (
select grade_desc
, max(score_range_id) score_range_id 
from score_range_master 
group by grade_desc) aa left join (
select grade_desc 
,sum(a.ever0) ever0 
,round((sum(a.ever0)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever0 
,sum(a.ever1_30) ever1_30 
,round((sum(a.ever1_30)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever1_30 
,sum(a.ever31_60) ever31_60 
,round((sum(a.ever31_60)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever31_60 
,sum(a.ever61_90) ever61_90 
,round((sum(a.ever61_90)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever61_90 
,sum(a.delmore_90) delmore_90 
,round((sum(a.delmore_90)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever_more90 
,sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) total_active 
,round(((sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90)) /
case when max(b.active) = 0 then 1 else max(b.active) end)*100,2) per_active 
from prepare_source_st15 a inner join (
select sum(ever0) + sum(ever1_30) + sum(ever31_60) + sum(ever61_90) + sum(delmore_90) active 
from prepare_source_st15 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/11/2020','dd/mm/yyyy') 
and last_day(to_date('30/11/2021','dd/mm/yyyy'))) b on 1 = 1 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/11/2020','dd/mm/yyyy') 
and last_day(to_date('30/11/2021','dd/mm/yyyy')) 
group by a.grade_desc) bb on aa.grade_desc = bb.grade_desc union all 
select 0 score_range_id 
,'Total' grade_desc 
,sum(a.ever0) ever0 
,round((sum(a.ever0)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever0 
,sum(a.ever1_30) ever1_30 
,round((sum(a.ever1_30)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever1_30 
,sum(a.ever31_60) ever31_60 
,round((sum(a.ever31_60)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever31_60 
,sum(a.ever61_90) ever61_90 
,round((sum(a.ever61_90)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever61_90 
,sum(a.delmore_90) delmore_90 
,round((sum(a.delmore_90)/
case when sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) = 0 then 1 else sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) end)*100,2) per_ever_more90 
,sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90) total_active 
,round(((sum(a.ever0) + sum(a.ever1_30) + sum(a.ever31_60) + sum(a.ever61_90) + sum(a.delmore_90)) /
case when max(b.active) = 0 then 1 else max(b.active) end)*100,2) per_active 
from prepare_source_st15 a inner join (
select sum(ever0) + sum(ever1_30) + sum(ever31_60) + sum(ever61_90) + sum(delmore_90) active 
from prepare_source_st15 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/11/2020','dd/mm/yyyy') 
and last_day(to_date('30/11/2021','dd/mm/yyyy'))) b on 1 = 1 
where product_type = 'CC-บัตรเครดิต' 
and model_name = 'CREDIT CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) 
and create_date between to_date('01/11/2020','dd/mm/yyyy') 
and last_day(to_date('30/11/2021','dd/mm/yyyy')) ) all_ 
order by all_.score_range_id desc