with t as ( 
select aaa.sseq 
,aaa.all_year 
,aaa.all_year_ 
,aaa.all_year approve_date 
,nvl(bbb.delmore_90,0) delmore_90 
,nvl(bbb.total_account,0) total_account 
,nvl(bbb.total_account,0) total_account_ 
from (
select a.* 
,a.month_detail||' '||b.all_year all_year 
,b.all_year all_year_ 
from master_quater a left join (
select yyear all_year 
from prepare_source_st11 
group by yyear) b on 1 = 1 
where all_year||' '||sseq not in (
select aa.year_||' '||aa.sseq all_ 
from (
select a.*
, b.year_ 
from master_quater a left join (
select yyear year_ 
from prepare_source_st11 
group by yyear) b on 1 = 1) aa 
where aa.year_ = (
select min(yyear) year_ 
from prepare_source_st11) 
and aa.sseq in (1,2,3) union all 
select aa.year_||' '||aa.sseq all_ 
from (
select a.*
, b.year_ 
from master_quater a left join (
select yyear year_ 
from prepare_source_st11 
group by yyear) b on 1 = 1) aa 
where aa.year_ = (
select max(yyear) year_ 
from prepare_source_st11) 
and aa.sseq in (2,3,4) 
and (
select count(*) 
from (
select yyear 
from prepare_source_st11 
group by yyear) a) >= 4) ) aaa left join (
select aa.month_detail||' '||bb.yyear all_q 
,sum(nvl(actual,0)) total_account 
,sum(nvl(bb.delmore_90_closed,0)) delmore_90 
from master_quater aa inner join (
select yyear 
,mmonth 
,delmore_90_closed 
,actual 
from prepare_source_st11 
where product_type = 'RL-บัตรกดเงินสด GSB' 
and model_name = 'PEOPLE CARD' 
and ('รวมทุกประเภทบัตร' = 'รวมทุกประเภทบัตร' 
or card_type = 'รวมทุกประเภทบัตร') 
and model_version = '1.0' 
and create_date <= last_day(to_date('01/'||'11'||'2020','dd/mm/yyyy')) 
and ('รวมทุกช่องทาง' = 'รวมทุกช่องทาง' 
or sales_channel in ('รวมทุกช่องทาง')) 
and ('รวมทุกสายงานกิจการ' = 'รวมทุกสายงานกิจการ' 
or business_type in ('รวมทุกสายงานกิจการ')) 
and ('รวมทุกภาค' = 'รวมทุกภาค' 
or region_name in ('รวมทุกภาค')) 
and ('รวมทุกเขต' = 'รวมทุกเขต' 
or zone_name in ('รวมทุกเขต')) 
and ('รวมทุกสาขา' = 'รวมทุกสาขา' 
or branch_name in ('รวมทุกสาขา')) ) bb on bb.mmonth between aa.min_month 
and aa.max_month 
group by aa.month_detail||' '||bb.yyear) bbb on aaa.all_year = bbb.all_q ) 
select * 
from t pivot (sum(nvl(delmore_90,0)) for all_year in ('ต.ค.-ธ.ค. (Q1) 2020','ม.ค.-มี.ค. (Q2) 2021','เม.ย.-มิ.ย. (Q3) 2021','ก.ค.-ก.ย. (Q4) 2021','ต.ค.-ธ.ค. (Q1) 2021') ) order by all_year_ asc
, sseq asc