TRUNCATE TABLE MASTER_BURE_SCORE;
COMMIT;
Insert into MASTER_BURE_SCORE (BUREAU_SCORE,FLAG,SSEQ) values ('ความเสี่ยงต่ำ (AA-BB)','AA-BB',1);
Insert into MASTER_BURE_SCORE (BUREAU_SCORE,FLAG,SSEQ) values ('ความเสี่ยงปานกลาง (CC-DD)','CC-DD',2);
Insert into MASTER_BURE_SCORE (BUREAU_SCORE,FLAG,SSEQ) values ('ความเสี่ยงค่อนข้างสูง (EE-FF)','EE-FF',3);
Insert into MASTER_BURE_SCORE (BUREAU_SCORE,FLAG,SSEQ) values ('ความเสี่ยงสูง (GG-HH)','GG-HH',4);
Insert into MASTER_BURE_SCORE (BUREAU_SCORE,FLAG,SSEQ) values ('เกรดอื่นๆ','Other',5);
COMMIT;